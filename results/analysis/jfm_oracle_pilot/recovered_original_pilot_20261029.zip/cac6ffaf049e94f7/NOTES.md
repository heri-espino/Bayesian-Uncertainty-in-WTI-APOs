# JFM pilot — not a manuscript result

This bounded synthetic experiment uses no purchased data. The statistical reference is a Curran-model price at known sigma, NOT an exact payoff value. Correlation stress uses a separate antithetic MC oracle with standard errors. Check numerical error before interpreting small differences. This run is development evidence, not a frozen confirmatory experiment.
